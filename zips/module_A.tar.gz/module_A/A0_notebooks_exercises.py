#!/usr/bin/env python
# coding: utf-8

# ### The Autograder
# 
# > Insert some exercise that teaches people how to use the autograder, maybe add a bit closer to when the autograder is polished and we've decided the exact workflow.
# 
# In the code cell below, change False to True. The autograder can be finicky, and you must be exact with certain naming conventions, so do not change anything else.
# 

# In[1]:


give_me_the_password = False
