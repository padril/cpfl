#!/usr/bin/env python
# coding: utf-8

# # Module C, Problem Set 1A
# 
# [Go back to the hub](../Hub.ipynb) \
# [Go back to Lesson 1](./Lesson_1_booleans.ipynb)

# ### Question 1
# 
# What should the value of `q1` be in the following expression if the output of the expression is `True`? Create a code cell, and assign this value to `q1`. 
# 
# ```Python
# q1 == 'hello'
# ```

# ### Question 2
# 
# What should the value of `q2` be in the following expression if the output of the expression is `False`? Assign this value to `q2`. 
# 
# ```Python
# q2 <= 4
# ```

# ### Question 3
# 
# Assign a value to `q3` so that the expression on the second line of the following code block outputs `True`.
# ```Python
# x = 10
# x < q3
# ```

# ### Question 4
# 
# What does the following expression evaluate to? Assign your answer to `q4`.
# 
# ```
# 9  != '9'
# ```

# ### Question 5
# 
# Consider the following expression and assign a value to `q5` so that the output becomes `True`.
# 
# ```Python
# q5 > 'a' and q5 < 'r'
# ```

# ### Question 6
# Consider the following expression and assign a value to `q6` so that the output becomes `True`.
# 
# ```Python
# q6 > 10 or q6 < 10
# ```

# ### Question 7
# 
# Consider the following expression and assign a value to `q7` so that the output becomes `True`.
# 
# ```Python
# not q7 % 3 == 0
# ```

# ### Question 8
# 
# Write a function, `q8`, that takes two numbers and returns `True` when their sum is greater than their product.

# In[1]:


def q8(x, y):
    return x + y > x * y

