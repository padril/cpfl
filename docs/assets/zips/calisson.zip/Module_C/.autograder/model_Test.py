from autograder.model_problem import ModelProblem

def threshold(score: float):
    if score >= 0.79:
        return "You passed! Congratulations! The password for the next module is: dumle"
    else:
        return f"Try again."

# model notebook needs:
# solution functions
# prep functions (which create lists of arguments for the solution + student functions)
# model functions (which instantiate the ModelProblem class and run the tests)

## SOLUTIONS ##
# same format as student functions, but return the correct answer
q1 = False
q1_test = lambda x: x == "brrrr"
q2 = True
q2_test = lambda x: x > book and "letter" in x
q3 = True
q3_test = lambda x: (x != "book") or ("book" == "bad")
def q4_fn(temperature):
    if temperature < 10:
        return "Too cold"
    elif temperature > 40:
        return "Too hot"
    else:
        return "Just right"
def q5_fn(length, width):
    return (length <= width * 1.1) and (width <= length * 1.1)

## PREP ##
# return format is list of tuples with the first element being the list of args (can be partial)
# and the second element being the visibility of the tests connected to that list of args
# (if the list of args in the prep fuunction is only partial, the remaining arguments need to be specified
# in extra_sfunc_args and extra_model_args when initializing the ModelProblem class)

def model_var_prep():
    return [([], True)]

def model_q4_prep():
    return [([x], True) for x in range(-10,50)]

def model_q4_prep():
    return [([x, y], True) for x in range(-20,20) for y in range(-20, 20)]

## Tests ##
def model_q1(student_var):
    model = ModelProblem(model_var_prep, q1, q1_test(student_var), is_var=True)
    return model.run_basic_tests()

def model_q2(student_var):
    model = ModelProblem(model_var_prep, q2, q2_test(student_var), is_var=True)
    return model.run_basic_tests()

def model_q3(student_var):
    model = ModelProblem(model_var_prep, q3, q3_test(student_var), is_var=True)
    return model.run_basic_tests()

def model_q4(student_fn):
    model = ModelProblem(model_q4_prep, q4_fn, student_fn)
    return model.run_basic_tests()

def model_q5(student_fn):
    model = ModelProblem(model_q5_prep, q5_fn, student_fn)
    return model.run_basic_tests()

