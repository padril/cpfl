from autograder.model_problem import ModelProblem

def threshold(score: float):
    if score >= 0.99:
        return "You passed! You should move on to Lesson 2"
    else:
        return f"Try again."

# model notebook needs:
# solution functions
# prep functions (which create lists of arguments for the solution + student functions)
# model functions (which instantiate the ModelProblem class and run the tests)

## SOLUTIONS ##
# same format as student functions, but return the correct answer
q1_test = lambda x: not x < 10
q2_test = lambda x: x != "book"
q3_var = True
q4_test = lambda x: not (x > 0 and x < 20)
q5_test = lambda x: not (x == 0 or x == 10)
q6_test = lambda x: x < 20
def q7_fn(x, y):
    return x * y > 0

## PREP ##
# return format is list of tuples with the first element being the list of args (can be partial)
# and the second element being the visibility of the tests connected to that list of args
# (if the list of args in the prep fuunction is only partial, the remaining arguments need to be specified
# in extra_sfunc_args and extra_model_args when initializing the ModelProblem class)

def model_var_prep():
    return [([], True)]

def model_q7_prep():
    return [([x, y], True) for x in range(-10,10) for y in range(-10,10)]

## Tests ##
def model_q1(student_var):
    res = q1_test(student_var)
    model = ModelProblem(model_var_prep, True, res, is_var=True)
    return model.run_basic_tests()

def model_q2(student_var):
    res = q2_test(student_var)
    model = ModelProblem(model_var_prep, True, res, is_var=True)
    return model.run_basic_tests()

def model_q3(student_var):
    model = ModelProblem(model_var_prep, q3_var, student_var, is_var=True)
    return model.run_basic_tests()

def model_q4(student_var):
    res = q4_test(student_var)
    model = ModelProblem(model_var_prep, True, res, is_var=True)
    return model.run_basic_tests()

def model_q5(student_var):
    res = q5_test(student_var)
    model = ModelProblem(model_var_prep, True, res, is_var=True)
    return model.run_basic_tests()

def model_q6(student_var):
    res = q6_test(student_var)
    model = ModelProblem(model_var_prep, True, res, is_var=True)
    return model.run_basic_tests()

def model_q7(student_fn):
    model = ModelProblem(model_q7_prep, q7_fn, student_fn)
    return model.run_basic_tests()
