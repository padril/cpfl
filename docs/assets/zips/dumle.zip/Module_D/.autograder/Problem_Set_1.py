#!/usr/bin/env python
# coding: utf-8

# # Module D, Problem Set 1
# 
# [Go back to the hub](../Hub.ipynb) \
# [Go back to Lesson 1](Lesson_1_lists.ipynb)

# ### Question 1
# 
# Assign a list consisting of the numbers 1, 5 and 8 to a variable called `q1`

# ### Question 2
# 
# Consider the variables `first` and `second` and use these variables to create a list where the first element is `first` and the second element is `second`. Store the list in a variable `q2`.

# In[ ]:


first = 1
second = 'a'
q2 = ...


# ### Question 3
# 
# Assign a list consisting of all positive even numbers up to and including 10 to a variable called `q3`. Note that 0 is neither positive nor negative.

# ### Question 4
# 
# If the variable `spam` contains a list as shown below, what is the value of `spam[3]`? Store this value in a variable `q4`.
# 
# ```Python
# spam = ['a', 'b', 'c', 'd']
# ```

# ### Question 5
# 
# Consider the following variable `units` which contains a list of strings. Assign the zeroeth unit in the list to `q5`.
# 
# ```Python
# units = ['kilometers', 'meters', 'miles', 'inches']
# ```

# ### Question 6
# 
# Consider the following variable `units` which contains a list of strings. Assign positive values to `q6a` and `q6b` so that the value of the variable `measure` becomes `'kilometers'`.
# 
# ```Python
# units = [['kilometers', 'meters', 'miles'], ['kilograms', 'pounds', 'stone']]
# measure = units[q6a][q6b]
# ```

# ### Question 7
# 
# Assume the list in `names` below. Slice the list so that the first and last names are no longer part of it and store the result in a variable called `q7`

# In[ ]:


names = ['Adri', 'Bert', 'Chris', 'Dirk', 'Evert', 'Frits', 'Geert']


# ### Question 8
# 
# Define a function, called `q8`, that takes a list as an argument, carries out the slicing operation described in Question 7 on that list, and returns the result

# ### Next steps
# 
# When you've finished all the problems and feel like you've improved your understanding of the material, you can move on to the next problem set.
# 
# [Go to Lesson 2](./Lesson_2_iteration.ipynb)
