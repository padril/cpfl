#!/usr/bin/env python
# coding: utf-8

# [Go back to the hub](../Hub.ipynb) \
# [Go back to Lesson 1](./Lesson_1_notebooks.ipynb)

# ### The Autograder
# 
# Throughout these notebooks, you will have **three ways to assess your progress**:
# - Practice exercises
# - Problem sets
# - Tests
# 
# **Practice exercises** will be sprinkled throughout your lessons and will be ungraded. It's meant for you to experiment, try new things, and not worry too much about getting things right. A lot of the time, practice exercises will involve asking you to make mistakes for the sake of seeing what works and what doesn't.
# 
# **Problem sets** (like this notebook) are graded. The intended progression is for you to do the problem set associated with each lesson right after finishing reading it. To get feedback, there will be a code cell that you can run. This will tell you which problems you got right and wrong, and sometimes nudge you in the direction of a correct solution. You can skip problem sets if you're already extremely familiar with the material, but we really suggest taking the time to do them! On the other side, **if you're still feeling like you need more practice with the material:** there are extra problem set questions in the folder "Additional_Exercises". Please note that these do not have autograder support.
# 
# **Tests** are the milestones at the end of each module. They will cover material from the entire module, and will be graded using the same autograder as the problem sets. If you get 80% of the questions right, you will receive a **password**, which you can enter into [the hub](../installer.ipynb) to get access to the next module. We'll tell you more about how this works when you finish module A.

# ### Some practice exercises
# 
# Experiment with the basics of notebooks some more! Here are a couple of things you can try to do:
# - create a code cell that carries out the arithmetic operation of subtracting seven from four, and run it.
# - change that code cell into a markdown cell, and run it (what changes?).
# - create a new markdown cell with the header '1.1.8 My Secret Notebook Section'.
# - change that markdown cell into a code cell, and run it (what happens?).
# - run the code cell above again, and interrupt it.
# - restart the kernel
# - clear all outputs

# ### Problem 1
# 
# For this problem set, we're just going to make sure that you can get the autograder up and running. Below is the **autograder cell**. You don't need to understand what the code inside does; just click on the cell and run it (either with Shift+Enter or the "run" button at the top bar of the notebook), and see what happens!

# You probably got some feedback saying that you didn't get it right. That's okay! In the cell below, change `False` to `True`, and re-run it. You should see that this time you got it right. If you didn't get it right, check to see if you made a typo—the autograder can be very finicky.

# In[1]:


i_love_python = False


# ### Next steps
# 
# Great! When you've finished all the problems and feel like you understand the material well enough, you can move on to the next lesson.
# 
# [Go to Lesson 2](./Lesson_2_operators.ipynb)
