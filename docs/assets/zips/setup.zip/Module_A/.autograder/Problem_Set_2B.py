#!/usr/bin/env python
# coding: utf-8

# # Module A, Problem Set 2B
# 
# <div class="alert alert-block alert-info">
# <b>Only attempt these</b> after you've completed Lesson A3 (Variables) as well, since you'll need some machinery from there.
# </div>
# 
# [Go back to the hub](../Hub.ipynb) \
# [Go back to Problem Set 2A](./Problem_Set_2A.ipynb)
# 
# 
# This problem set covers the same material as Problem Set 2A. If you found that you understood that notebook, we recommend skipping this one for now and coming back to it in a day or two to refresh your understanding.

# ### Question 1
# What value will the following expression give?
# 
# ```Python
# 9.0%2
# ````
# 
# Assign the answer to a variable called `q1`

# In[2]:


q1 = ...


# ### Question 2
# 
# What value will the following expression give?
# 
# ```Python
# 9//-2
# ````
# Assign the answer to a variable called `q2`

# In[3]:


q2 = ...


# ## Question 3
# 
# Use Python to calulate the area of a rectangle with length of 4 and width of 60. Store the output in a variable called `q3`

# In[4]:


q3 = ...


# ## Question 4
# 
# What do you expect to be the output of this calculation: 
# 
# ```python
# 10*10.0
# ```
# 
# Store your answer in a variable called q4

# In[5]:


q4 = ...


# ## Question 5
# 
# What is the output of these calculations?
# 
# ```python
# 4.0%2
# ```
# 
# Store your answer in a variable called `q5`

# In[6]:


q5 = ...


# ## Question 6
# 
# What is the data type of the following value: `"Linguistics is cool"`  
# Please assign your answer as a String variable to `q6`.
# E.g. `q11 = "int"`
# 
# The possible answers are "str", "int", "bool", "float", and "NoneType".

# In[7]:


q6 = "..."


# ## Question 7
# 
# Consider a variable that represents the total cost of a shopping trip in dollars and cents.
# 
# What type should its value be?
# 
# NOTE: Please assign your answer as a String variable to `q7`. 
# E.g. `q7 = "int"`
# 
# The possible answers are "str", "int", "bool", "float", and "NoneType".

# In[8]:


q7 = "..."

