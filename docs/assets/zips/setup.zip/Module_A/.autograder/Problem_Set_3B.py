#!/usr/bin/env python
# coding: utf-8

# # Module A, Problem Set 3B
# 
# [Go back to the hub](../Hub.ipynb) \
# [Go back to Problem Set 3A](./Problem_Set_3A.ipynb)
# 
# This problem set covers the same material as Problem Set 3A. If you found that you understood that notebook, we recommend skipping this one for now ([and moving on to Lesson 4](./Lesson_4_statements.ipynb)) and coming back to it in a day or two to refresh your understanding.

# ### Question 1
# 
# The following statement produces an error message because the variable name is not valid. Remove one character so that the variable name becomes valid.
# 
# ```Python
# 1x = 10
# ```
# 
# Store the new variable name as a String in a variable called `q1`

# In[ ]:


q1 = ...


# ### Question 2
# 
# Suppose you have the following variables describing the three spatial dimensions of a box:
# 
# ```python
# width = 20
# height = 12
# length = 10
# ```
# 
# Create a new variable, called `q2` that is assigned the volume (width $\times$ height $\times$ length) of the box. Do so by (1) creating and assigning the variables as listed above, and (2) by using those variables in the assignment of the new variable `q2`.

# In[7]:


width = ...
# add the other helper variables here, too!
q2 = ...


# ### Question 3
# 
# What is the type of `x` after running this code? Store your answer as a string in the variable `q3`
# 
# ```python
# x = 2
# x = 2.0
# x = 'hello'
# x = x
# ```

# In[8]:


q3 = ...


# ### Question 4
# 
# You are buying groceries and below is your total cost, in dollars:
# 
# ```python
# q4 = 48.99
# ```
# 
# You decide to add another item that costs $25.   
# Increment `q4` to get the new total cost.

# In[9]:


q4 = 48.99



# ### Question 5
# 
# What is the value of `count` after executing the following code block?
# 
# ````python
# 
# count = 20
# 
# count /= 2
# count /= 2
# ````
# 
# Assign your answer as an integer to `q5`.

# In[10]:


q5 = ...


# ### Next steps
# 
# [Go to Lesson 4](./Lesson_4_statements.ipynb)
