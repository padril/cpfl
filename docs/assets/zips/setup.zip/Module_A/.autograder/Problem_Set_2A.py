#!/usr/bin/env python
# coding: utf-8

# # Module A, Problem Set 2A
# 
# <div class="alert alert-block alert-info">
# <b>Only attempt these</b> after you've completed Lesson A3 (Variables) as well, since you'll need some machinery from there.
# </div>
# 
# [Go back to the hub](../Hub.ipynb) \
# [Go back to Lesson 3](./Lesson_3_variables.ipynb)

# ### Question 1
# 
# What value will the following expression give?
# 
# ```Python
# 9%2
# ```
# 
# Assign the answer to a variable called `q1` in the below code cell (we've done this one for you)

# In[ ]:


q1 = 1


# ### Question 2
# 
# What value will the following expression give?
# 
# ```Python
# 9//2
# ````
# Assign the answer to a variable called `q2`
# 
# Note: `...` acts as a placeholder in Python,

# In[1]:


q2 = ...


# ### Question 3
# 
# If `x` has a negative value like the one below, what happens when we add x to another value?
# 
# ```python
# x = -17
# ````
# 
# What is the value of `5+x`?
# Assign the answer to a variable called `q3`

# In[2]:


q3 = ...


# ### Question 4
# 
# Suppose the cover price of a book is \\$24.95, but bookstores get a 40\% discount. Shipping costs $3 for the first copy and 75 cents for each additional copy. What is the total wholesale cost for 60 copies?
# 
# Assign the answer to a variable called `q4`

# In[3]:


q4 = ...


# ### Question 5
# 
# What is the output of this calculation?
# 
# ```python
# (10*3)%5
# ```
# 
# Store your answer in a variable called `q5`

# In[4]:


q5 = ...


# ### Question 6
# 
# What is the data type of the following value: `False`  
# Please assign your answer as a String variable to `q6`.
# 
# E.g. `q6 = "int"`
# 
# The possible answers are "str", "int", "bool", "float", and "NoneType".

# In[6]:


q6 = ...


# ## Next steps
# 
# When you've finished all the problems and feel like you've improved your understanding of the material, you can move on to the next problem set.
# 
# [Go to Problem Set 2B](./Problem_Set_2B.ipynb)
