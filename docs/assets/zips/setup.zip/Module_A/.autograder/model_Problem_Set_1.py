from autograder.model_problem import ModelProblem

def threshold(score: float):
    if score >= 0.99:
        return "You passed! You should move on to Lesson 2"
    else:
        return f"Try again."

# model notebook needs:
# solution functions
# prep functions (which create lists of arguments for the solution + student functions)
# model functions (which instantiate the ModelProblem class and run the tests)

## SOLUTIONS ##
# same format as student functions, but return the correct answer
i_love_python = True

## PREP ##
# return format is list of tuples with the first element being the list of args (can be partial)
# and the second element being the visibility of the tests connected to that list of args
# (if the list of args in the prep fuunction is only partial, the remaining arguments need to be specified
# in extra_sfunc_args and extra_model_args when initializing the ModelProblem class)

def model_i_love_python_prep():
    return [([], True)]

## Tests ##
def model_i_love_python(student_var):
    model = ModelProblem(model_i_love_python_prep, i_love_python, student_var, is_var=True)

    return model.run_basic_tests()

