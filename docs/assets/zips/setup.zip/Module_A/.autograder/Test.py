#!/usr/bin/env python
# coding: utf-8

# # Module A, Test
# 
# [Go back to the hub](../Hub.ipynb) \
# [Go back to Problem Set 4](Problem_Set_4.ipynb)

# In[3]:


# Run this cell to autograde the notebook!
# Remember to save your changes to see them reflected in your score.
import ipynbname
from autograder.score_assignment import score
score(ipynbname.path())


# Congratulations on making it through your first module! At the end of every module, you will have to attempt a **test** to demonstrate your knowledge and move on to the next section.
# 
# But don't worry! You can make as many attempts as you want! Once you get 4/5 of the questions right (but still try for the full 5/5), you'll receive a password which you can put in the Hub to fetch the next module.

# ### Question 1
# What value will the following expression give?
# 
# ```Python
# 'boo' * 2
# ````
# 
# Create a code cell and assign the answer to a variable called `q1`

# In[ ]:


q1 = ...


# ### Question 2
# 
# Use Python to calulate the area of a rectangle with length of 3 and width of 13. Store the length in a variable called `length` and the width in a variable called `width`. Use these two variables to assigning the area to the variable ` q2`

# ### Question 3
# 
# The following statement produces an error message because the variable name is not valid. Change the name of the variable by removing only the part of the name that produces the error.
# 
# ```Python
# number= = 100
# ```
# 
# Store the new variable name as a String in a variable called `q3`

# ### Question 4
# 
# What is the value of `count` after executing the following code block?
# 
# ````python
# 
# count = 10
# 
# count -= -4
# count -= 1
# count -= 3
# ````
# 
# Assign your answer as an integer to `q4`.

# ### Question 5
# 
# Is the following an expression or a statement?
# 
# ```Python
# n = 2
# ````
# 
# Assign the answer as a string to a variable called `q5`

# ### Next steps
# 
# **Got 4/5?** We recommend you trying for 5/5, but if you feel ready:
# - Copy and paste the password to your clipboard
# - [Go back to the hub](../Hub.ipynb)
# - Paste the password into the `password = "setup"` assignment (replace the word setup)
# - Run all celsl of the hub notebook!
