#!/usr/bin/env python
# coding: utf-8

# # Module A, Problem Set 3

# [Go back to the hub](../Hub.ipynb) \
# [Go back to Problem Set 2B](./Problem_Set_2B.ipynb)

# ### Question 1
# 
# Assign the floating point number 9.3 to a variable called `q1`

# In[1]:


q1 = ...


# ### Question 2
# 
# The following statement produces an error message because the variable name is not valid. Change the name of the variable by removing only the part of the name that produces the error.
# 
# ```Python
# one hundred = 100
# ```
# 
# Store the new variable name as a String in a variable called `q2`

# In[2]:


q2 = ...


# ### Question 3
# 
# Consider the variables below:
# 
# ```python
# x = 10.5
# y = 4
# ```
# 
# Make the variable `x` refer to the sum of `x`and `y`. What are the new values of `x`and `y`now? Assign the value of `x` to a variable called `q3`

# In[3]:


q3 = ...


# ### Question 4
# 
# What is the final value of `y` at the end of this code? Store your answer in a variable called `q4`
# 
# ```python
# x = 10
# y = 11
# c = x
# x = y
# y = c
# ```

# In[4]:


q4 = ...


# ### Question 5
# 
# What is the value of `count` after executing the following code block?
# 
# ````python
# 
# count = 0
# 
# count += 2
# count += 2
# count += 3
# ````
# 
# Assign your answer as an integer to `q5`.

# In[5]:


q5 = ...


# ### Next steps
# 
# [Go to Problem Set 3B](./Problem_Set_3B.ipynb)
