#!/usr/bin/env python
# coding: utf-8

# # Module A, Problem Set 4

# [Go back to the hub](../Hub.ipynb) \
# [Go back to Lesson 4](./Lesson_4_statements.ipynb)

# In[2]:


# Run this cell to autograde the notebook!
import ipynbname
from autograder.score_assignment import score
score(ipynbname.path())


# ### Question 1
# 
# Which of the following is a statement?
# 
# ```Python
# spam = 10        # 1
# 'spam' + 'spam'  # 2
# ````
# 
# Assign the answer as an integer (i.e., `1` or `2`) to a variable called `q1`

# In[ ]:


q1 = ...


# ### Question 2
# 
# Is the following an expression or a statement?
# 
# ```Python
# 10
# ````
# 
# Assign the answer as a string to a variable called `q2`

# In[ ]:


q2 = ...


# ### Question 3
# 
# What will be the output of the variable `spam` given the following statement?
# 
# ```Python
# spam = 10
# ````
# 
# Assign the answer to a variable called `q3`

# In[ ]:


q3 = ...


# ### Question 4
# 
# What will be the output of the following expression?
# 
# ```Python
# 'spam' + 'spam'
# ````
# 
# Assign the answer to a variable called `q4`

# In[ ]:


q4 = ...


# ### Question 5
# Set the value of the variable `q5` to be something which causes the following expression to result in an error message.
# 
# ```Python
# 'I am ' + q5 + ' years old.'
# ````

# In[3]:


q5 = ...


# ### Next steps
# 
# **Wow**! If you finished all of those questions, you're now ready for the **Module A test**. More information about how it works is in the below link.
# 
# [Go to the test, and finish Module A!](Test.ipynb)
